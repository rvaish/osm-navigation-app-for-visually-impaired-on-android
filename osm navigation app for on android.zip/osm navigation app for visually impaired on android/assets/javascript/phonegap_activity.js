/*
 * This is to Initialize phonegap and device
 */
/*
function init()
{
	document.addEventListener("touchmove", preventBehavior, false);
	document.addEventListener("deviceready", deviceInfo, true);		
}
*/	